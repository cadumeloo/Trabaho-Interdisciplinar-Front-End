// Função para carregar os dados dos filmes do JSON
function loadMoviesFromJSON(callback) {
    fetch('JSON.json')
        .then(response => response.json())
        .then(data => callback(data))
        .catch(error => console.error('Erro ao carregar os filmes:', error));
}

// Função para adicionar os filmes à página
function addMoviesToPage(movies) {
    const movieList = document.getElementById('movieList');
    movieList.innerHTML = '';
    console.log(movies)
    movies.forEach(movie => {
        if(movie.curtida == 1){
            const movieDiv = document.createElement('div');
            movieDiv.classList.add('movie');
            movieDiv.innerHTML = `
                <div class="col-12">
                    <img src="${movie.image}" alt="${movie.title}">
                    <p><strong>${movie.title}</strong></p>
                    <p>Data de Lançamento: ${movie.releaseDate}</p>
                </div>
            `;
            movieList.appendChild(movieDiv);
        }
    });
}

// Função para alternar a exibição das opções de filtro
function toggleFilter() {
    const filterOptions = document.getElementById('filterOptions');
    filterOptions.style.display = filterOptions.style.display === 'block' ? 'none' : 'block';
}

// Adiciona os filmes à página ao carregar
window.onload = function() {
    loadMoviesFromJSON(addMoviesToPage);
};
