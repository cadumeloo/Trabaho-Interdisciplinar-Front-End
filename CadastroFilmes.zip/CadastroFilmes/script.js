
$(document).ready(function() {
    $('#movieForm').submit(function(event) {
        event.preventDefault();
        var fileInput = $('#foto')[0];
        if (fileInput.files.length === 0) {
            alert('Por favor, selecione uma imagem.');
            return;
        }

        var uniqueID = 'movie-' + Date.now();

        var formData = new FormData(this);
        var movieData = {
            id: uniqueID,
            nome: formData.get("nome"),
            sinopse: formData.get("sinopse"),
            categorias: [$("#categorias").val()],
            data: formData.get("data"),
            ondeEncontrar: formData.get("ondeEncontrar").split(',').map(item => item.trim()),
            atores: formData.get("atores").split(',').map(item => item.trim()),
            imdb: formData.get("imdb"),
            rotten: formData.get("rottenTomatoes"),
        };

        // Converte a imagem para base64
        getBase64(fileInput.files[0]).then(fotoData => {
            movieData.foto = fotoData;

            // Envia os dados para o servidor
            $.ajax({
                url: 'https://74d72406-59af-43c7-8b17-8a57fb527e10-00-1ffcuaryhf96y.worf.replit.dev/filmes',
                type: 'POST',
                data: JSON.stringify(movieData),
                contentType: "application/json",
                success: function(response) {
                    console.log("Filme cadastrado com sucesso", response);
                    $('#movieForm')[0].reset();
                },
                error: function(error) {
                    console.log("Falha ao cadastrar filme", error);
                }
            });
        });
    });

    function getBase64(file) {
        return new Promise((resolve, reject) => {
            const reader = new FileReader();
            reader.readAsDataURL(file);
            reader.onload = () => resolve(reader.result);
            reader.onerror = error => reject(error);
        });
    }
});


var choices = new Choices('#categorias', {
    allowHTML: true,
    removeItemButton: false,
    searchEnabled: true,
    placeholder: true,
    placeholderValue: 'Selecione as categorias',
    searchPlaceholderValue: 'Pesquise um esporte',
    itemSelectText: 'Pressione para selecionar',
    maxItemCount: 10,
    renderChoiceLimit: 10
});

/*link json server https://replit.com/@cadumelosabino/json-cadastroFIlmes#index.js*/
/*OBS: SIM, a foto fica daquele tamanho dentro do json msm*/ 










/*============================================================================================================================================================================================*/
/*==========================================================================  IGNORE A PARTIR DAQUI ==========================================================================================*/
/*============================================================================================================================================================================================*/

/*                                                                    (apenas testes que deram errado abaixo)                                                                                 */





















/*$('#movieForm').submit(function(event) {
    event.preventDefault();
    
    // Get the image file
    let imageFile = $('#imagem')[0].files[0];
    
    // Create a FormData object to handle file upload
    let formData = new FormData();
    formData.append('nome', $("#nome").val());
    formData.append('sinopse', $("#sinopse").val());
    formData.append('categorias', $("#categorias").val());
    formData.append('data', $("#data").val());
    formData.append('ondeEncontrar', $("#ondeEncontrar").val().split(',').map(item => item.trim()));
    formData.append('imdb', $("#imdb").val());
    formData.append('rotten', $("#rottenTomatoes").val());
    formData.append('atores', $("#atores").val().split(',').map(item => item.trim()));
    formData.append('imagem', imageFile);  // Add the image file

    $.ajax({
        url: 'https://74d72406-59af-43c7-8b17-8a57fb527e10-00-1ffcuaryhf96y.worf.replit.dev/filmes',
        type: 'POST',
        data: formData,
        processData: false,  // Important: prevent jQuery from automatically transforming the data into a query string
        contentType: false,  // Important: prevent jQuery from setting the Content-Type
        success: function(response) {
            console.log("Filme cadastrado com sucesso", response);
        },
        error: function(error) {
            console.log("Falha ao cadastrar filme", error);
        }
    });
});

$("#categorias").select2({
    placeholder: "Selecione as categorias",
});*/



/*$('#movieForm').submit(function(event) {
    event.preventDefault();
    console.log($("#categorias").val())
    $.ajax({
        url:'https://74d72406-59af-43c7-8b17-8a57fb527e10-00-1ffcuaryhf96y.worf.replit.dev/filmes',
        type:'POST',
        data: JSON.stringify({
            nome: $("#nome").val(),
            sinopse: $("#sinopse").val(),
            categorias: [
                $("#categorias").val(),
            ],
            data: $("#data").val(),
            ondeEncontrar: [
                $("#ondeEncontrar").val().split(',').map(item => item.trim()),
            ],
            imdb: $("#imdb").val(),
            rotten: $("#rottenTomatoes").val(),
            atores: [
                $("#atores").val().split(',').map(item => item.trim()),
            ],
            
        }),
        contentType:"application/json",
        success: function(response) {
            console.log("Filme cadastrado com sucesso", response);
        },
        error: function(error) {
            console.log("Falha ao cadastrar filme", error);
        }
    })
})

$("#categorias").select2({
    placeholder: "Slecione as categorias",
})*/
/* <-----------------------------------------------------------------------------------//-------------------------------------------------------------------------------------------------> */

/*document.addEventListener("DOMContentLoaded", () => {
    const movieForm = document.getElementById("movieForm");

    movieForm.addEventListener("submit", async (e) => {
        e.preventDefault();

        const formData = new FormData(movieForm);
        const movieData = {
            nome: formData.get("nome"),
            sinopse: formData.get("sinopse"),
            categorias: formData.get("categorias"),
            data: formData.get("data"),
            ondeEncontrar: [
                formData.get("ondeEncontrar").split(',').map(item => item.trim()),
            ],
            notas: {
                imdb: formData.get("imdb"),
                rottenTomatoes: formData.get("rottenTomatoes")
            },
            diretor: formData.get("diretor"),
            atores: [ 
                formData.get("atores").split(',').map(item => item.trim())
            ],
        };

        // Handle file upload
        const fotoFile = formData.get("foto");
        const fotoData = await getBase64(fotoFile);
        movieData.foto = fotoData;

        // Save the data to JSON server
        fetch("https://74d72406-59af-43c7-8b17-8a57fb527e10-00-1ffcuaryhf96y.worf.replit.dev/filmes", {
            method: "POST",
            headers: {
                "Content-Type": "application/json"
            },
            body: JSON.stringify(movieData)
        })
        .then(response => response.json())
        .then(data => {
            console.log("Success:", data);
            movieForm.reset();
        })
        .catch((error) => {
            console.error("Error:", error);
        });
    });
    
});*/
