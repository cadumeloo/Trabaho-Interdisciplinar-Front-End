document.getElementById('survey-form').addEventListener('submit', function(event) {
    event.preventDefault();

    const favoriteActorsDirectors = document.getElementById('favorite-actors-directors').value;
    const favoriteMovies = document.getElementById('favorite-movies').value;
    const genres = Array.from(document.querySelectorAll('input[name="genres"]:checked')).map(checkbox => checkbox.value);

    const response = {
        favoriteActorsDirectors,
        favoriteMovies,
        genres
    };

    let responses = JSON.parse(localStorage.getItem('responses')) || [];
    responses.push(response);
    localStorage.setItem('responses', JSON.stringify(responses));

    document.getElementById('survey-form').reset();

    displayResponses();
});

function displayResponses() {
    const responses = JSON.parse(localStorage.getItem('responses')) || [];
    const storedResponsesDiv = document.getElementById('stored-responses');
    storedResponsesDiv.innerHTML = '';

    responses.forEach(response => {
        const responseDiv = document.createElement('div');
        responseDiv.classList.add('response');

        responseDiv.innerHTML = `
            <p><strong>Atores e Diretores Favoritos:</strong> ${response.favoriteActorsDirectors || 'Não respondido'}</p>
            <p><strong>Filmes Favoritos:</strong> ${response.favoriteMovies || 'Não respondido'}</p>
            <p><strong>Gêneros Favoritos:</strong> ${response.genres.length > 0 ? response.genres.join(', ') : 'Não respondido'}</p>
        `;

        storedResponsesDiv.appendChild(responseDiv);
    });
}

document.addEventListener('DOMContentLoaded', displayResponses);