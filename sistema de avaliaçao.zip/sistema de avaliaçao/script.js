// Função para adicionar estrelas de avaliação
function adicionarEstrelas(nota) {
  const estrelas = document.querySelectorAll('.estrela');
  estrelas.forEach((estrela, index) => {
    if (index < nota) {
      estrela.classList.add('ativa');
    } else {
      estrela.classList.remove('ativa');
    }
  });
}

// Função para curtir o filme
function curtirFilme(element) {
  element.classList.toggle("ativo");
}

// Função para salvar a publicação
function salvarPublicacao() {
  const texto = document.getElementById('texto').value;
  const nota = document.querySelectorAll('.estrela.ativa').length;
  const curtida = document.querySelector('.coracao').classList.contains('ativo');
  const data = document.getElementById('data').value;
  const plataforma = document.getElementById('plataforma').value;
  const imagem = "oppenhaimer_poster_4k.png"; // Nome do arquivo de imagem
  
  const publicacao = {
    texto: texto,
    nota: nota,
    curtida: curtida,
    data: data,
    plataforma: plataforma,
    imagem: imagem
  };

  console.log(JSON.stringify(publicacao));
}

// Função para formatar a data
function formatarData(input) {
  const valor = input.value.replace(/\D/g, '');
  const partes = [];
  
  if (valor.length > 0) partes.push(valor.substring(0, 2));
  if (valor.length > 2) partes.push(valor.substring(2, 4));
  if (valor.length > 4) partes.push(valor.substring(4, 8));
  
  input.value = partes.join('/');
}

// Event listeners para estrelas de avaliação
document.querySelectorAll('.estrela').forEach((estrela, index) => {
  estrela.addEventListener('click', () => {
    if (estrela.classList.contains('ativa')) {
      adicionarEstrelas(index);
    } else {
      adicionarEstrelas(index + 1);
    }
  });
});

// Event listener para botão de curtir
document.querySelector('.coracao').addEventListener('click', curtirFilme);

// Event listener para botão de salvar publicação
document.getElementById('salvar').addEventListener('click', salvarPublicacao);
